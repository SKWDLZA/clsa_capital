<!-- 主页 -->
<template>
	<view style="position: relative;">
		<view class="bg_home_header">
			<Header></Header>
		</view>
		<!-- <view style="position: absolute;top:60px;left: 50%;transform: translateX(-50%);">
			<image src="/static/home_banner.png" mode="widthFix" style="width: 343px;height: 164px;"></image>
		</view> -->
		<view style="margin-top: -18vh;">
			<view class="common_block">
				<ButtonGroup :btns="$util.BTNS_CONFIG_HOME"></ButtonGroup>
			</view>
			<GoodsList ref="goods"></GoodsList>
		</view>

		<!-- 公告弹层 -->
		<template v-if="ipoSuccess && isShow">
			<view class="mask" @click="handleClose">
				<view style="position: fixed;top: 26vh;right: 12vw;z-index: 1000;" @click="handleClose">
					<image src="/static/close.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
				</view>
				<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
					<view class="bg_ad"
						style="display: flex;flex-wrap: nowrap;flex-direction: column; align-items: center;border-radius: 20px;">
						<view
							style="text-align: center;font-size: 36rpx;color:#121212;padding-bottom: 16px;padding-top: 16px;">
							축하합니다 </view>
						<view
							style="width: 90%;background-color: #fbfdff;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin:10px 0 20px 0;">

							<view style="font-size: 20px;padding: 10px 0 2px 0;color: rgb(6, 190, 216);">
								【{{ipoSuccess.goods.number_code}}】 {{ipoSuccess.goods.name}}
							</view>
							<view style="font-size: 12px;color:#999;padding:2px 0 10px 0;">
								공모주청약 당첨되었습니다.
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-around;">
								<view>배치 수량</view>
								<text style="font-weight: 700;color: rgb(255, 133, 0);font-size: 16px;">
									{{$util.formatNumber(ipoSuccess.success)}}</text>
							</view>
							<view
								style="padding: 10px 0;display: flex;align-items: center;justify-content: space-around;">
								<view>일시금</view>
								<text
									style="font-weight: 700;color: rgb(255, 133, 0);font-size: 16px;">{{$util.formatNumber(ipoSuccess.total)}}</text>
							</view>
							<view
								style="padding: 10px 0;line-height: 1;background-color: #f6df46;border-radius: 100px;color:#121212;margin:20px 30px;"
								@click="$u.route('/pages/index/components/newShares/luckyNumber/luckyNumber');">바로보기
							</view>
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,
				isShow: true, // 是否显示ad层,
				ipoSuccess: null, // 消息
			}
		},

		onLoad() {
			this.getData();
		},

		onShow() {
			this.startTimer();
			if (this.$refs.goods) {
				this.$refs.goods.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			// AD层关闭
			handleClose() {
				this.isShow = false;
			},
			linkNotify() {
				uni.navigateTo({
					url: ``
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					this.$refs.goods.getList();
				}, 3000);
			},
			// 银转证
			async silver() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
			// 获取通知
			async getData() {
				const result = await this.$http.get('api/goods-shengou/tanchuang', {})
				if (result.data.data[0]) {
					this.isShow = true;
					
					this.ipoSuccessItem = result.data.data[0];
				}
				console.log('抢筹', result.data.data[0]);
			}
		},
	}
</script>

<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		background-image: url(/static/bg_center.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		min-height: 40vh;
		max-height: 60vh;
		width: 80vw;
	}
</style>