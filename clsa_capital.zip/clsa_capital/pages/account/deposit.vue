<!-- 银转证  存款 -->
<template>
	<view :style="{height:`${ $util.calcPageHeight()}px`}">
		<view class="header_wrapper_10">
			<CustomHeader :title="$lang.DEPOSIT" @action="handleBack()"></CustomHeader>
		</view>
		<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;">
			<view style="font-size: 28px;font-weight: 900;" :style="{color:$util.THEME.TEXT_DARK}">
				{{$util.formatNumber(userInfo.money)}}
			</view>
			<view style="padding:20px;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
			<view class="common_btn btn_primary" style="width: 60%;margin:auto;" @click="handleCustomer()">
				고객센터로 문의하세요
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				userInfo: {},
			};
		},
		onLoad(option) {
			this.getInfo()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			async handleCustomer() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>