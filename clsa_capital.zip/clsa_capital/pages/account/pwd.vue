<template>
	<view >
		<view class="header_wrapper_10">
			<CustomHeader title="비밀번호 재설정" @action="handleBack()"></CustomHeader>
		</view>
		<view class="common_block"
			style="display: flex;flex-direction: column;justify-content: center;align-items: center;margin-top:6vh;">
			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value" type="password" :placeholder="$lang.OLD_PWD" style=""></input>
			</view>

			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value2" type="password" :placeholder="$lang.NEW_PWD"></input>
			</view>

			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value3" type="password" :placeholder="$lang.NEW_PWD2"></input>
			</view>
			<view class="common_btn btn_primary" style="width:50%;margin: 20px 0;" @click="changePassword">확인</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},
			//修改登录密码
			async changePassword() {
				const result = await this.$http.post(this.$http.API_URL.SIGNIN_PASSWORD, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (result.data.code == 0) {
					uni.$u.toast('수정되었습니다.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>