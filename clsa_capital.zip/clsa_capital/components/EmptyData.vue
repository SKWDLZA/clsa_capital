<template>
	<view class="empty">{{$lang.ENPTY_DATA}}</view>
</template>

<script>
	export default {
		name: "EmptyData",
		data() {
			return {

			};
		}
	}
</script>

<style>

</style>