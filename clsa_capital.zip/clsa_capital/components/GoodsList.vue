<template>
	<view class="common_block" style="padding-bottom: 6px;border-top-left-radius: 12px;border-top-right-radius: 12px;">
		<view style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between; margin-left: 10px;">
			<view style="padding-left: 10px; font-size: 14px;" :style="{color:$util.THEME.TEXT}">인기종목</view>
			<image mode="aspectFit" src="/static/stock_all.png" :style="$util.calcImageSize(16)"></image>
		</view>
		
		<EmptyData v-if="list && list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view @click="handleDetail(item.code)"
				style="display: flex;align-items: center;font-size: 16px;background-color: #F8F7FC;border-radius: 8px;margin:12px;padding: 6px 10px">
				<view style="display: inline-block;flex:6%;">
					<template v-if="!item.logo || item.logo==''">
						<view :style="$util.calcImageSize(30)" style="background-color:#2d2c62;text-align: center;line-height: 30px;color: #FFFFFF;margin-bottom: 4px;">{{item.ko_name.slice(0,1)}}</view>
					</template>
					<template v-else>
						<image mode="aspectFit" :src="item.logo" :style="$util.calcImageSize(30)"></image>
					</template>	
				</view>
				<view style="display: inline-block;flex:44%;padding-left: 6px;" :style="{color:$util.THEME.TEXT}">
					{{item.ko_name}}
				</view>
				<text style="display: inline-block;flex:25%;text-align: right;padding-right: 10px;"
					:style="$util.calcStyleRiseFall(item.returns>0)">{{$util.formatNumber(item.close*1)}}
				</text>
				<view
					style="border-radius: 3px;font-weight: 700; display: inline-block;flex:25%;text-align: right;margin-right: 10px;"
					:style="$util.calcStyleRiseFall(item.returns>0)">
					<view style="display: inline-block;padding-right:4px;">
						{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
					</view>
					<!-- <image mode="aspectFit" :src="`/static/${item.returns>0?'up':'down'}.png`"
						:style="$util.calcImageSize(12)"></image> -->
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList();
		},
		methods: {
			handleAllList() {
				console.log('???')
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_ALL}?type=0`,
				})
			},
			handleDetail(code) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}`,
				})
			},
			async getList() {
				// if (this.list.length <= 0) {
				// 	uni.showLoading({
				// 		title: this.$lang.LOADING,
				// 	})
				// }
				const result = await this.$http.get(this.$http.API_URL.GOODS_LIST, {
					page: 1,
					gp_index: 0
				})
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>