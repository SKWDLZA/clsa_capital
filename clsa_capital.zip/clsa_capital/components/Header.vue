<template>
	<view class="common_header">
		<view class="primary_header_left" @click="$u.route({url:$util.PAGE_URL.SEARCH});">
			<image mode="aspectFit" src="/static/search.png" :style="$util.calcImageSize(16)"></image>
		</view>
		<view class="primary_header_right">
			<image mode="aspectFit" src="/static/notification.png" :style="$util.calcImageSize(20)"
				@click="$u.route({url:$util.PAGE_URL.NOTIFICATION});" style="padding:0 16px;"></image>
			<image mode="aspectFit" src="/static/service.png" :style="$util.calcImageSize(20)" @click="linkService()"
				style="padding-right:16px;"></image>
			<image mode="aspectFit" src="/static/sign_out.png" :style="$util.calcImageSize(20)" @click="handleSignOut()"
				style=""></image>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Header",
		data() {
			return {};
		},
		methods: {
			linkService() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				})
			},
			handleSignOut() {
				this.$http.post(this.$http.API_URL.SIGN_OUT, );
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('성공적으로 종료');
				setTimeout(() => {
					uni.navigateTo({
						url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>