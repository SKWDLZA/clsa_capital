<!-- 个人交易 交易信息 -->
<template>
	<view>
		<view class="common_block" style="padding: 10px;">
			<view style="display: flex;align-items: center;">
				<view style="flex:10%;font-size: 16px;font-weight: 700;" :style="{color:$util.THEME.TIP}">
					205-01-{{info.uid}}
				</view>
				<view class="hui font-size-10" style="flex:10%;">[CMA]{{info.real_name}}</view>
				<view class="common_btn btn_secondary" style="width: 20%;margin-top: 10px;transform: scale(0.85);"
					@click="handleDeposit">
					{{$lang.DEPOSIT}}
				</view>
			</view>
			<view style="font-size: 24px;font-weight: 700;" :style="{color:$util.THEME.TEXT_DARK}">
				{{$util.formatNumber(info.money)}}
			</view>
		</view>

		<view class="common_block" style="padding:10px;">
			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.TOTAL_BUY_AMOUNT}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.PRIMARY}">
						{{$util.formatNumber(info.frozen)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.VALUATION_GAIN_LOSS}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.holdYingli)}}
					</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.VALUATION_GAIN_LOSS_AMOUNT}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.guzhi)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.RATE_RESPONSE}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.TEXT}">
						{{info.huibao}}%
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;line-height: 2.5;">
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.AMOUNT_TOTAL}}
					</view>
					<view style="display: inline-block;padding-left: 4px;" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(info.totalZichan)}}
					</view>
				</view>
				<view class="trade_info_item">
					<view style="display: inline-block;width: 55px;" :style="{color:$util.THEME.TIP}">
						{{$lang.TOTAL_GAIN}} 
					</view>
					<view style="display: inline-block;padding-left: 4px;"
						:style="$util.calcStyleRiseFall(info.totalYingli>0)">
						{{$util.formatNumber(info.totalYingli)}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		data() {
			return {
				info: {},
			};
		},
		mounted() {
			this.getUserInfo()
		},
		methods: {
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				});
			},
			async getUserInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})

				if (result.data.code == 0) {
					this.info = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>